from pyecharts import options as opts
from pyecharts.charts import Line
import csv
from pyecharts.charts import Bar
from pyecharts import options as opts
from pyecharts.options.global_options import AxisOpts

x = []
y1 = []
with open('Bitcoin_tweets_clean.csv', 'r', encoding='ANSI') as f:
    reader=csv.reader(f)
    for item in reader:
        if reader.line_num == 1:
            continue
        if reader.line_num > 50000:
            break
        #print(int(item[1])+int(item[2]))
        x.append(item[0])
        y1.append(item[5])

#折线图的数据格式：x轴和y轴都是列表数据


def set_line():
    line = Line()
    line.add_xaxis(xaxis_data = x)

    #添加y轴数据，加上series_name，表示图例
    line.add_yaxis(series_name = '折线图',y_axis = y1)

    line.set_global_opts(
        #设置图例形状
        legend_opts=opts.LegendOpts(legend_icon='pin'),
        yaxis_opts=opts.AxisOpts(name='user_followers'),
        xaxis_opts=opts.AxisOpts(name='index')

        #设置图表主标题，副标题和标题位置
        #title_opts=opts.TitleOpts(title = '我喜欢的九位歌手',subtitle='数错了,是十位',pos_left='10%'),
        #title_opts=opts.TitleOpts(title='我喜欢的九位歌手', pos_left='10%'),

        #添加坐标轴名称，位置以及大小，name_gap表示名称与x轴距离，font_size是字体大小
        #xaxis_opts = opts.AxisOpts(name = '年份',name_location='center',name_gap=25,name_textstyle_opts=opts.TextStyleOpts(font_size = 20)),
        #yaxis_opts = opts.AxisOpts(name = '数量/篇')

        )
    return line

line = set_line()
line.render('index-user_followers.html')

