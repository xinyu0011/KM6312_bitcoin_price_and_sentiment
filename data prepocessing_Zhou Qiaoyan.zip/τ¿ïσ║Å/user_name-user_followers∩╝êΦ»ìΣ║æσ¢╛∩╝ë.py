import pyecharts.options as opts
from pyecharts.charts import WordCloud
import csv


x = []
y= []
x1 = ()
y1 = ()
data = []
with open('Bitcoin_tweets_clean.csv', 'r', encoding='ANSI') as f:
    reader=csv.reader(f)
    for item in reader:
        if reader.line_num > 180000:
            break
        if reader.line_num == 1:
            continue
        x1 = (item[1],item[5])
        # x.append(item[9])
        # y.append(item[0])
        data.append(x1)
print(data)


(
    WordCloud()
    .add(series_name="词云图", data_pair=data, word_size_range=[26, 66])
    .set_global_opts(
        title_opts=opts.TitleOpts(
            title="词云图", title_textstyle_opts=opts.TextStyleOpts(font_size=23)
        ),
        tooltip_opts=opts.TooltipOpts(is_show=True),
    )
    .render("user_name-user_followers.html")
)
