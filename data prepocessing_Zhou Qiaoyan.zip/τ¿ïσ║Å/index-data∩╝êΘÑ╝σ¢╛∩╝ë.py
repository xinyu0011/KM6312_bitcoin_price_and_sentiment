from pyecharts import options as opts
#导入Pie类
from pyecharts.charts import Pie
import csv

x = []
y1 = []
with open('Bitcoin_tweets_clean.csv', 'r', encoding='ANSI') as f:
    reader=csv.reader(f)
    for item in reader:
        if reader.line_num > 108:
            break
        if reader.line_num == 1:
            continue
        #print(int(item[1])+int(item[2]))
        x.append(item[9])
        y1.append(item[0])
#饼图的数据类型，为列表的嵌套：[[key1, value1], [key2, value2]]
song_list = y1
singer_list = x
#使用zip函数
#再将其中的元组转换成列表
data_pair =  [list(i) for i in zip(singer_list,song_list)]

def set_pie():
    pie = Pie()
    pie.add(
        series_name = '',
        data_pair = data_pair,
        color = 'red',
        #设置图表的标签(指示图表区域),formatter是设置标签内容格式，在饼图中：{a}（系列名称），{b}（数据项名称），{c}（数值）, {d}（百分比）
        label_opts = opts.LabelOpts(is_show=True,formatter='{b}:{c} \n ({d}%)'),
        # 是否展示成南丁格尔图，通过半径区分数据大小，有'radius'和'area'两种模式。
        # radius：扇区圆心角展现数据的百分比，半径展现数据的大小
        # area：所有扇区圆心角相同，仅通过半径展现数据大小
        #rosetype = 'radius',
        # 饼图的半径，数组的第一项是内半径，第二项是外半径
        # 默认设置成百分比，相对于容器高宽中较小的一项的一半
        #radius=['20%','75%']
    )
    pie.set_global_opts(
        #设置图例形状,位置,orient表示横向还是纵向，horizontal和vertical
        legend_opts=opts.LegendOpts(legend_icon='pin',orient='vertical',pos_right='10%'),
        #设置图表主标题，副标题和标题位置
        title_opts=opts.TitleOpts(title = '饼图',pos_left='20%'),
    )
    #设置饼图的颜色，可选项，不设也有默认的颜色。
    pie.set_colors(['blue','red','orange','yellow','green','purple','black','brown','pink','grey'])
    return pie

pie = set_pie()
pie.render('index-data（饼图）.html')
