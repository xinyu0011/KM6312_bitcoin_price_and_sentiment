import csv
from pyecharts.charts import Bar
from pyecharts import options as opts
from pyecharts.options.global_options import AxisOpts

x = []
y1 = []
with open('Bitcoin_tweets_clean.csv', 'r', encoding='ANSI') as f:
    reader=csv.reader(f)
    for item in reader:
        if reader.line_num == 1:
            continue
        if reader.line_num > 100000:
            break
        #print(int(item[1])+int(item[2]))
        x.append(item[0])
        y1.append(item[6])


#x = ['餐饮','娱乐','交通','保养','衣服']
#y1= [1000,500,100,5000,5000]
#y2= [2000,1000,100,20,30]


bar = Bar()
bar.add_xaxis(xaxis_data = x)
#第一个参数是图例的名称
bar.add_yaxis(series_name = '柱状图',y_axis = y1)
#bar.add_yaxis(series_name = 'fan某人',y_axis = y2)

#添加options
bar.set_global_opts(
                    yaxis_opts=opts.AxisOpts(name='user_friends'),
                    xaxis_opts=opts.AxisOpts(name='index')
                    )

#生成HTML文件
bar.render('index-user_friends.html')
